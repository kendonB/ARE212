PEW RESEARCH CENTER FOR THE PEOPLE & THE PRESS
OCTOBER POLITICAL SURVEY
October 4-7, 2012
N=1,511

***************************************************************************************************************************

This dataset includes cell phone interviews conducted using an RDD sample of cell phone numbers. 
Cell phone interviews include households that are cell-only as well as those that also have a landline phone. 
The dataset contains several weight variables. 

WEIGHT is the weight for the combined sample of all landline and cell phone interviews. 
Data for all Pew Research Center reports are analyzed using this weight.

Two other weights can be used to compare the combined sample with the landline sample by itself 
and with the landline sample combined with the cell-only households.

LLWEIGHT is for analysis of the landline RDD sample only. Interviews conducted by cellphone are not 
given a weight and are excluded from analysis when this weight is used.

COWEIGHT is for analysis of the combined landline RDD sample and the cell-only cases. 
Cases from the cell phone RDD sample that reported having a landline phone are not given 
a weight and are excluded from analysis when this weight is used.

Two additional weights related to likely voters lvs7wt64 and unlvs7wt64 are described below with the likely voter syntax.

***************************************************************************************************************************

Beginning in the Fall of 2008, the Pew Research Center started using respondents� self-reported zip code as  
the basis for geographic variables such as region, state and county. We do this because the error rate in the original 
geographic information associated with the sample is quite high, especially for respondents from the cell phone sample. 

For respondents who do not provide a zip code or for those we cannot match, we use the sample geographic information. 
We continue to include the original sample geographic variables in the datasets (these variables are preceded by an �s�) 
for archival purposes only.

To protect the privacy of respondents, telephone numbers, county of residence and zip code have been removed from the data file.

***************************************************************************************************************************

Releases from this survey:

October 8, 2012 "Romney's Strong Debate Performance Erases Obama's Lead"
http://www.people-press.org/2012/10/08/romneys-strong-debate-performance-erases-obamas-lead/

October 10, 2012 "Biden Viewed Unfavorably, Divided Opinions about Ryan"
http://www.people-press.org/2012/10/10/biden-viewed-unfavorably-divided-opinions-about-ryan/
(NOTE: Some of the data on which this report is based are from the Oct. 4-7, 2012, omnibus survey.)

October 12,0212, "Deep Divisions over Debt Reduction Proposals"
http://www.people-press.org/2012/10/12/deep-divisions-over-debt-reduction-proposals/

October 15, 2012, "More Say There Is Solid Evidence of Global Warming"
http://www.people-press.org/2012/10/15/more-say-there-is-solid-evidence-of-global-warming/

October 18, 2012, "On Eve of Foreign Debate, Growing Pessimism about Arab Spring Aftermath"
http://www.people-press.org/2012/10/18/on-eve-of-foreign-debate-growing-pessimism-about-arab-spring-aftermath/

************************************************************************************************************************

SYNTAX

***The likely voter scale is computed using the following variables***.

*Recode LVS variables*.
recode THOUGHT (1 thru 2=1) (else=0) into XTHOUGHT.
recode CAMPNII (1 thru 2=1) (else=0) into XCAMPNII.
recode FOLGOV (1 thru 2=1) (else=0) into XFOLGOV.
recode OFTVOTE (1 thru 2=1) (else=0) into XOFTVOTE.
recode PRECINCT (1=1) (else=0) into XPRECINCT.
recode PVOTE08A (1=1) (else=0) into XPVOTE08.
recode WHERE (1,3,4=1) (else=0) into XWHERE.
recode PLANTO2 (1=1) (else=0) into XPLANTO2.
recode SCALE10 (9 thru 10=1) (else=0) into XSCALE10.

*Compute 7-point LVS scale*.
*18-21 no pvote, but compensation point. .additional .5 for 18-24.
if age ge 22 lvs7=XTHOUGHT+XCAMPNII+XOFTVOTE+XPRECINCT+XPLANTO2+XSCALE10+XPVOTE08.
if age le 21 lvs7=XTHOUGHT+XCAMPNII+XOFTVOTE+XPRECINCT+XPLANTO2+XSCALE10+1.
if age le 24 lvs7=lvs7+.5.
if lvs7>7 lvs7=7.
if reg>1 lvs7=0.
if planto1=2 lvs7=0.
*Note: early voters coded to top*.
if planto1=3 lvs7=7.
var lab lvs7 "7-point likely voter scale, replacement point for < 21. additional .5 for <24".

*A weight for likely Voters is computed based on the likely voter scale 
 (predicting 59% turnout--using a 64% cutoff for the scale).
*This weight (lvs7wt64) should be used when analyzing likely voters*.
weight off.
if lvs7>4 lvs7wt64=weight.
if lvs7=4 lvs7wt64=weight*.57126082.
if lvs7<4 lvs7wt64=0.

*This unlikely voter weight (unlvs7wt64) is only used in comparison with likely voters.
 (this includes all those not considered likely voters--including non registered)*.
if lvs7>4 unlvs7wt64=0.
if lvs7=4 unlvs7wt64=weight*.42873918.
if lvs7<4 unlvs7wt64=weight.
var label unlvs7wt64 'weight for unlikely voters'.

******** SYNTAX FOR HORSE RACE BASED ON REGISTERED VOTERS*************.
do if reg=1.
compute Q5horse=0.
if (q5=2 or q5a=2) q5horse=1.
if (q5=1 or q5a=1) q5horse=2.
if ((q5=3 and q5a ge 3) or q5a=3) q5horse=3.
if (q5 ge 8 and q5a ge 8) q5horse=9.
end if.
var lab q5horse �Obama-Romney Horserace�.
val lab q5horse 1 'Obama/lean Obama' 2 'Romney/lean Romney' 3 'Other-refused to lean'
9 'DK-refused to lean�.


****SYNTAX FOR SWING VOTERS**********************.

do if reg=1.
if (q5=2) and (q7>1) swing=1.
if (q5=1) and (q8>1) swing=2.
if (q5a=2 or (q5=2 and q7=1)) swing=3.
if (q5a=1 or (q5=1 and q8=1)) swing=4.
if (q5a>2) swing=5.
end if.
var lab swing '2012 Swing Vote Preference'.
val lab swing 1 'Certain OBAMA �no chance Romney'
              2 'Certain ROMNEY- no chance Obama'
              3 'Obama-Lean Obama -- Chance Romney'
              4 'Romney-Lean Romney -- Chance Obama'
              5 'Other/Undecided'.


****SYNTAX FOR BATTLE GROUND STATES**********************.
recode state 
(1,2,4,5,13,16,18,20,21,22,28,29,30,31,38,40,45,46,47,48,49,54,56=1)
(6,9,10,11,15,17,23,24,25,26,27,34,35,36,41,42,44,50,53=2) 
(8,12,19,32,33,37,39,51,55=3) into battle.
var label battle 'Red, Blue & Battle'.
val label battle 1'Republican states' 2 'Democratic states' 3 'Battleground states'.
