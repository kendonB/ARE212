PEW RESEARCH CENTER FOR THE PEOPLE & THE PRESS AND
PEW FORUM ON RELIGION AND PUBLIC LIFE
NOVEMBER 2011 RELIGION AND POLITICS SURVEY
NOVEMBER 9-14, 2011 
TOTAL N=2,001

***************************************************************************************************************************

This dataset includes cell phone interviews conducted using an RDD sample of cell phone numbers. 
Cell phone interviews include households that are cell-only as well as those that also have a landline phone. 
The dataset contains several weight variables. 

WEIGHT is the weight for the combined sample of all landline and cell phone interviews. 
Data for all Pew Research Center reports are analyzed using this weight.

Two other weights can be used to compare the combined sample with the landline sample by itself 
and with the landline sample combined with the cell-only households.

LLWEIGHT is for analysis of the landline RDD sample only. Interviews conducted by cellphone are not 
given a weight and are excluded from analysis when this weight is used.

COWEIGHT is for analysis of the combined landline RDD sample and the cell-only cases. 
Cases from the cell phone RDD sample that reported having a landline phone are not given 
a weight and are excluded from analysis when this weight is used.

***************************************************************************************************************************

Beginning in the Fall of 2008, the Pew Research Center started using respondents� self-reported zip code as  
the basis for geographic variables such as region, state and county. We do this because the error rate in the original 
geographic information associated with the sample is quite high, especially for respondents from the cell phone sample. 

For respondents who do not provide a zip code or for those we cannot match, we use the sample geographic information. 
We continue to include the original sample geographic variables in the datasets (these variables are preceded by an �s�) 
for archival purposes only.

To protect the privacy of respondents, telephone numbers, county of residence and zip code have been removed from the data file.

***************************************************************************************************************************

Due to a programming error with Q53, a small number of respondents who gave an answer in Q.51a-c were not asked the 
appropriate follow-up in Q.53a-c. Respondents who were affected by this error were called back to get their responses to Q.53a-c. 
Responses to Q.53a-c in the report and topline have been re-percentaged based on those who were correctly asked Q.53a-c, 
either in the intial interview or the callback interview. 