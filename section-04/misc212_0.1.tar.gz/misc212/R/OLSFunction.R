OLS <- function(y,X) {
  b <- solve(t(X) %*% X) %*% t(X) %*% y
  b
}